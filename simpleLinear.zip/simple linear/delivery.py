# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 08:23:38 2020

@author: AAYUSH VOHRA
"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
dt_st=pd.read_csv("G:/practical data science/Assignments/simple linear/delivery_time.csv")
dt_st.head()
dt_st.corr()
plt.scatter(x=dt_st.st , y=dt_st.dt, color='green')
plt.xlabel("Sorting time")
plt.ylabel("Delivery time")
plt.boxplot(dt_st.dt)

plt.hist(dt_st.dt, bins=5)
import statsmodels.formula.api as smf
model2=smf.ols("dt~st",data=dt_st).fit()
model2.params
model2.summary()
model3=smf.ols("dt~np.log(st)",data=dt_st).fit()
model3.params
model3.summary()
model2.conf_int(0.05) 
model3.conf_int(0.05)
pred2 = model2.predict(dt_st)
pred3 = model3.predict(dt_st)
plt.scatter(x=dt_st.st, y=dt_st.dt, color='green')
plt.plot(dt_st.st, pred2,color='black')
plt.xlabel("Sorting time")
plt.ylabel("Delivery time")

plt.scatter(x=dt_st.st, y=dt_st.dt, color='red')
plt.plot(dt_st.st, pred3,color='green')
plt.xlabel("Sorting time")
plt.ylabel("Delivery time")
