# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 08:37:00 2020

@author: AAYUSH VOHRA
"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
sal_churn=pd.read_csv("G:/practical data science/Assignments/simple linear/emp_data.csv")
sal_churn.head()
sal_churn.corr()
plt.scatter(x=sal_churn.Salary_hike, y=sal_churn.Churn_out_rate, color='blue')
plt.xlabel("Salary_hike")
plt.ylabel("Churn_out_rate")
plt.hist(sal_churn.Salary_hike)
plt.hist(sal_churn.Churn_out_rate)
sal_churn.describe()
import statsmodels.formula.api as smf
model4=smf.ols("Churn_out_rate~Salary_hike",data=sal_churn).fit()
model4.summary()
model4.params
model4.conf_int(0.05)
pred4 = model4.predict(sal_churn)
model5=smf.ols("Churn_out_rate~np.log(Salary_hike)",data=sal_churn).fit()
model5.summary()
model5.params
model5.conf_int(0.05)
pred5 = model5.predict(sal_churn)
plt.scatter(x=sal_churn.Salary_hike, y=sal_churn.Churn_out_rate, color='blue')
plt.plot(sal_churn.Salary_hike, pred5,color='black')
plt.xlabel("Salary_hike")
plt.ylabel("Churn_out_rate")
