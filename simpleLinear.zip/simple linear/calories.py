# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 08:54:31 2020

@author: AAYUSH VOHRA
"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
wg_cc=pd.read_csv("G:/practical data science/Assignments/simple linear/calories_consumed.csv")
wg_cc.head()
wg_cc.corr()
plt.scatter(x=wg_cc.cc, y=wg_cc.wg, color='red')
plt.xlabel("Calories Consumed")
plt.ylabel("Weight gained (grams)")
wg_cc.describe()
import statsmodels.formula.api as smf
model=smf.ols("wg~cc",data=wg_cc).fit()
model.params
model.summary()
model.conf_int(0.05)
pred = model.predict(wg_cc)
plt.scatter(x=wg_cc.cc, y=wg_cc.wg, color='red')
plt.plot(wg_cc.cc, pred,color='black')
plt.xlabel("Calories Consumed")
plt.ylabel("Weight gained (grams)")
pred.corr(wg_cc.wg)
model1 = smf.ols('wg~np.log(cc)',data=wg_cc).fit()
model1.params
model1.summary()
model1.conf_int(0.01)
pred1 = model1.predict(wg_cc)
pred1.corr(wg_cc.wg)
