# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 08:46:02 2020

@author: AAYUSH VOHRA
"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
sal_hike=pd.read_csv("G:/practical data science/Assignments/simple linear/Salary_Data.csv")
sal_hike.head()
sal_hike.shape
sal_hike.describe()
plt.boxplot(sal_hike.YearsExperience)
plt.boxplot(sal_hike.Salary)
sal_hike.corr()
plt.hist(sal_hike.Salary, bins=20)
plt.scatter(x=sal_hike.YearsExperience, y=sal_hike.Salary, color='blue')
plt.xlabel("YearsExperience")
plt.ylabel("Salary")
import statsmodels.formula.api as smf
model6=smf.ols("Salary~YearsExperience",data=sal_hike).fit()
model6.summary()
model7=smf.ols("Salary~np.log(YearsExperience)",data=sal_hike).fit()
model7.summary()
model8=smf.ols("Salary~np.exp(YearsExperience)",data=sal_hike).fit()
model8.summary()
model6.params
model7.params
model6.conf_int(0.05)
pred6 = model6.predict(sal_hike)
plt.scatter(x=sal_hike.YearsExperience, y=sal_hike.Salary, color='blue')
plt.plot(sal_hike.YearsExperience, pred6,color='black')
plt.xlabel("YearsExperience")
plt.ylabel("Salary")
pred7 = model7.predict(sal_hike)
plt.scatter(x=sal_hike.YearsExperience, y=sal_hike.Salary, color='blue')
plt.plot(sal_hike.YearsExperience, pred7,color='black')
plt.xlabel("YearsExperience")
plt.ylabel("Salary")
